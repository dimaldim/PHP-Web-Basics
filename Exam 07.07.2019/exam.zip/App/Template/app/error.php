<h2>Oops, and error occurred :(</h2>

<?php /** @var \App\Data\ErrorDTO $data */ ?>

<p style="color: red;"><?= $data->getMessage(); ?></p>
