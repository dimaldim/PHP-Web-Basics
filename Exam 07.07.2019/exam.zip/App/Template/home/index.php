<h1>Welcome to SoftUni Booking</h1>

If you have an account, you can
    <a href="login.php">login</a> to our system.
Otherwise, just <a href="register.php">register</a>.
