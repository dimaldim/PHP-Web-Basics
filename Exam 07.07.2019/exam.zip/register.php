<?php

require_once "common.php";

$userHttpHandler->register($_POST);
