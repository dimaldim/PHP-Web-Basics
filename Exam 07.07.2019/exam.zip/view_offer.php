<?php

require_once "common.php";

$itemHttpHandler->view($_GET);