<?php

require_once "common.php";

$itemHttpHandler->add($_POST);