<?php

require_once "common.php";

$itemHttpHandler->rent($_GET);
